=== Ms Post Type Shortcode ===
Contributors: onzpowr,sunilth123
Tags: post, category filter, blog , custom post grid, custom post slider, custom post paginate, shortcode.
Requires at least: 4.0
Tested up to: 5.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ms Post Type Shortcode is very lightweight plugin and help to display post in grid, slider, pagination.

== Description ==
The main purpose of this plugin is to display the custom post type posts and as well as default post in grid, slider, pagination. There are three type of shortcodes are available in plugin and some common and different parameters pass in all shortcode. This plugin also have grid, slider and pagination design setting available and very easy to use. 

**Shortcode**

<pre>[ms_post_grid]</pre>
Without passing any parameter in shortcode it will display post from default post type 'post' and term '1' (Uncategorized) in grid layout.

<pre>[ms_post_slider]</pre>
It will display post in slider.

<pre>[ms_post_paginate]</pre>
It will display post in pagination.

You can also pass the parameters in shortcode
<pre>[ms_post_grid type='here custom post type name' ms_show_all='true']</pre>

== Installation ==

**How to Install**

1.  Download Ms Post Type Shortcode.
2.  Unzip the folder into the /wp-content/plugins/ directory.
3.  Activate the plugin through the 'Plugins' menu in WordPress.
    Or upload zip file from wp-admin.
4.  After install the plugin user will redirect to plugin 'Introduction' page and user will know how the shortcode parameters will work.

== Frequently Asked Questions ==

= What about support? =

Create a support ticket at WordPress forum and I will take care of any issue.

== Screenshots ==
1. Design and slider setting screen in plugin.
2. Frontend View of grid and pagination.
3. Frontend View of slider layout.

== Changelog ==

= 1.0 =
* initial release