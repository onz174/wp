(function( $ ) {
    jQuery(function() {
        jQuery('.ms-color-picker').wpColorPicker();
    });
})( jQuery );